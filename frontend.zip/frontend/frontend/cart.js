// cart.js

document.addEventListener('DOMContentLoaded', () => {
    // --- Configuration & Elements ---
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const cartItemsContainer = document.getElementById('cart-items-container');
    const cartSummaryContainer = document.getElementById('cart-summary-container');
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    // --- Security Check & Initial Load ---
    if (!userInfo || !userInfo.token) {
        document.querySelector('.cart-container').innerHTML = '<h1>Access Denied</h1><p>Please <a href="/login.html">log in</a> to view your cart.</p>';
        return;
    }
    const token = userInfo.token;

    // --- RENDER FUNCTION: Takes cart data and builds the HTML ---
    const renderCart = (cart) => {
        // 1. Handle Empty Cart
        if (!cart || cart.length === 0) {
            cartItemsContainer.innerHTML = '<div class="empty-cart-message"><h2>Your cart is empty</h2><p>Looks like you haven\'t added anything to your cart yet.</p><a href="/" class="btn btn-primary">Continue Shopping</a></div>';
            cartSummaryContainer.style.display = 'none'; // Hide summary if cart is empty
            return;
        }

        // 2. If cart has items, show summary and clear old items
        cartSummaryContainer.style.display = 'block';
        cartItemsContainer.innerHTML = ''; // Clear "Loading..."

        let subtotal = 0;

        // 3. Loop through each item and create its HTML element
        cart.forEach(item => {
            // The item.product can be null if a product was deleted but still in cart
            if (!item.product) return; 

            const cartItemElement = document.createElement('div');
            cartItemElement.className = 'cart-item';
            cartItemElement.dataset.productId = item.product._id; // Store ID for easy access

            cartItemElement.innerHTML = `
                <img src="${item.product.image}" alt="${item.product.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <p class="cart-item-name">${item.product.name}</p>
                    <p class="cart-item-price">₹${item.product.price.toFixed(2)}</p>
                </div>
                <div class="cart-item-actions">
                    <div class="quantity-selector">
                        <button class="btn-quantity-change" data-change="-1">-</button>
                        <input type="number" class="quantity-input" value="${item.quantity}" min="1">
                        <button class="btn-quantity-change" data-change="1">+</button>
                    </div>
                    <button class="btn-remove-item">Remove</button>
                </div>
            `;
            cartItemsContainer.appendChild(cartItemElement);

            // 4. Calculate subtotal
            subtotal += item.product.price * item.quantity;
        });
        
        // 5. Update the subtotal in the summary box
        document.getElementById('cart-subtotal').textContent = `₹${subtotal.toFixed(2)}`;
    };

    // --- API HELPER: A single function to update the cart on the backend ---
    const updateCartAPI = async (productId, quantity) => {
        const response = await fetch(`${API_BASE_URL}/api/users/cart`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ productId, quantity })
        });
        if (!response.ok) throw new Error('Failed to update cart.');
        return response.json();
    };

    const removeCartItemAPI = async (productId) => {
        const response = await fetch(`${API_BASE_URL}/api/users/cart/${productId}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) throw new Error('Failed to remove item.');
        return response.json();
    };

    // --- INITIAL FETCH: Load the cart when the page opens ---
    const loadCart = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/api/users/cart`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Could not load cart.');
            const cart = await response.json();
            renderCart(cart);
        } catch (error) {
            cartItemsContainer.innerHTML = `<p class="error-text">${error.message}</p>`;
        }
    };

    // --- EVENT LISTENERS ---
    cartItemsContainer.addEventListener('click', async (e) => {
        const target = e.target;
        const cartItem = target.closest('.cart-item');
        if (!cartItem) return;
        const productId = cartItem.dataset.productId;

        // 1. Handle Quantity Change Buttons (+/-)
        if (target.classList.contains('btn-quantity-change')) {
            const change = parseInt(target.dataset.change, 10);
            const input = cartItem.querySelector('.quantity-input');
            let newQuantity = parseInt(input.value, 10) + change;
            if (newQuantity < 1) newQuantity = 1; // Don't allow less than 1
            input.value = newQuantity; // Update UI immediately
            
            const updatedCart = await updateCartAPI(productId, newQuantity);
            renderCart(updatedCart); // Re-render the whole cart to update subtotal
        }

        // 2. Handle Remove Button
        if (target.classList.contains('btn-remove-item')) {
            if (confirm('Are you sure you want to remove this item?')) {
                const updatedCart = await removeCartItemAPI(productId);
                renderCart(updatedCart); // Re-render cart
            }
        }
    });
    
    // Optional: Listener for typing in the quantity box
    cartItemsContainer.addEventListener('change', async (e) => {
        if (e.target.classList.contains('quantity-input')) {
            const cartItem = e.target.closest('.cart-item');
            const productId = cartItem.dataset.productId;
            let newQuantity = parseInt(e.target.value, 10);
            if (isNaN(newQuantity) || newQuantity < 1) {
                newQuantity = 1;
                e.target.value = 1;
            }
            const updatedCart = await updateCartAPI(productId, newQuantity);
            renderCart(updatedCart);
        }
    });

    // --- KICK OFF THE PROCESS ---
    loadCart();
});