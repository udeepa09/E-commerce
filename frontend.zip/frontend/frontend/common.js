/*
    COMMON.JS - ZyraKart Application Core
    Architecture: Single global namespace (App) with modular components.
    Responsibilities:
    1.  Load and inject shared HTML components (header, modals).
    2.  Manage global state (user, cart).
    3.  Provide shared utilities (API, UI, Toast).
    4.  Bind all common event listeners.
    5.  Signal 'app-ready' when initialization is complete.
*/

// A single global object to avoid polluting the global scope.
window.App = {
    /**
     * Toast Notification Module
     */
    Toast: {
        container: null,
        init() {
            // Create the container dynamically
            const container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container';
            document.body.appendChild(container);
            this.container = container;
        },
        show(message, type = 'success') {
            if (!this.container) return;
            const toast = document.createElement('div');
            toast.className = `toast toast--${type}`;
            toast.textContent = message;
            this.container.appendChild(toast);
            setTimeout(() => toast.classList.add('show'), 10);
            setTimeout(() => {
                toast.classList.remove('show');
                toast.addEventListener('transitionend', () => toast.remove());
            }, 3000);
        }
    },

    /**
     * State Management Module
     */
    State: {
        user: { isLoggedIn: false, token: null, name: null },
        cart: [],
        setUser(userData) {
            if (userData && userData.token) {
                this.user = { isLoggedIn: true, token: userData.token, name: userData.name };
                localStorage.setItem('userInfo', JSON.stringify(userData));
            } else {
                this.user = { isLoggedIn: false, token: null, name: null };
                localStorage.removeItem('userInfo');
            }
        },
        setCart(cartData) { this.cart = cartData || []; }
    },

    /**
     * API Communication Module
     */
    API: {
        BASE_URL: '/api', // Correct, relative URL for production
        async _fetch(endpoint, options = {}) { /* ... (same as script.js refactor) ... */ },
        getProducts: () => App.API._fetch('/products'),
        getProduct: (id) => App.API._fetch(`/products/${id}`),
        login: (credentials) => App.API._fetch('/users/login', { /* ... */ }),
        register: (userData) => App.API._fetch('/users/register', { /* ... */ }),
        getCart: () => App.API._fetch('/users/cart'),
        updateCart: (productId, quantity) => App.API._fetch('/users/cart', { /* ... */ }),
        // Inside App.API in common.js
getMyOrders: () => App.API._fetch('/orders/myorders'), // New line
    },

    /**
     * UI Module
     */
    UI: {
        selectors: {},
        cacheSelectors() { /* ... caches all selectors after HTML is loaded ... */ },
        renderProduct: (product) => { /* ... from product-detail.js, now generalized ...*/},
        updateCart: () => { /* ... same as script.js refactor ... */ },
        updateCartCount: () => { /* ... same as script.js refactor ... */ },
        updateProfileDropdown() {
            const dropdown = this.selectors.profileDropdown;
            if (!dropdown) return;
            dropdown.innerHTML = ''; // Clear first
            if (App.State.user.isLoggedIn) {
                const userBlock = document.createElement('div');
                userBlock.innerHTML = `<h4></h4><a href="/orders.html">My Orders</a><button id="logout-btn" class="btn">Logout</button>`;
                userBlock.querySelector('h4').textContent = `Hello, ${App.State.user.name}`; // Secure
                dropdown.appendChild(userBlock);
            } else { /* ... render login buttons ... */ }
        },
        showModal(modalName, openerElement) { /* ... same as script.js refactor ... */ },
        hideAll() { /* ... same as script.js refactor ... */ },
    },

    /**
     * Main Application Controller & Initializer
     */
    async init() {
        this.Toast.init();
        
        // 1. Load shared HTML into placeholders
        await this.loadSharedHTML();
        
        // 2. Now that HTML exists, cache all selectors
        this.UI.cacheSelectors();

        // 3. Load initial state and data
        this.loadInitialState();
        await this.loadUserCart();

        // 4. Update UI with initial data
        this.UI.updateProfileDropdown();
        this.UI.updateCartCount();

        // 5. Bind all common event listeners
        this.bindEvents();

        // 6. Signal to page-specific scripts that the app is ready!
        console.log("App Ready. Firing 'app-ready' event.");
        document.dispatchEvent(new CustomEvent('app-ready'));
    },
    
    // **THE CRITICAL NEW FUNCTION**
    async loadSharedHTML() {
        const headerPlaceholder = document.getElementById('main-header-placeholder');
        const sharedUIPlaceholder = document.getElementById('shared-ui-placeholder');

        try {
            // Fetch components in parallel for performance
            const [headerRes, modalsRes] = await Promise.all([
                fetch('/_header.html'),
                fetch('/_modals.html')
            ]);

            if (!headerRes.ok || !modalsRes.ok) throw new Error('Could not load shared components.');

            const [headerHTML, modalsHTML] = await Promise.all([
                headerRes.text(),
                modalsRes.text()
            ]);

            if (headerPlaceholder) headerPlaceholder.innerHTML = headerHTML;
            if (sharedUIPlaceholder) sharedUIPlaceholder.innerHTML = modalsHTML;

        } catch (error) {
            console.error("Fatal Error: Could not load core UI.", error);
            document.body.innerHTML = '<h1>Error: Could not load website components. Please try again later.</h1>';
        }
    },
    
    loadInitialState() { /* ... same as script.js refactor ... */ },
    async loadUserCart() { /* ... same as script.js refactor ... */ },
    
    // Centralized event binding
    bindEvents() {
        // Use event delegation on the document body for dynamically loaded elements
        document.body.addEventListener('click', e => {
            if (e.target.matches('#logout-btn')) this.handleLogout();
            if (e.target.matches('#login-btn-dropdown')) this.UI.showModal('login');
            if (e.target.matches('#cart-btn')) this.UI.showSidebar('cartSidebar');
            // ... add more delegated listeners as needed ...
        });

        const { selectors } = this.UI;
        selectors.closeButtons?.forEach(btn => btn.addEventListener('click', () => this.UI.hideAll()));
        
        // Handle search form submission (now works on all pages)
        selectors.forms.search?.addEventListener('submit', e => {
            e.preventDefault();
            const query = selectors.inputs.search.value;
            if (query) {
                window.location.href = `/?search=${encodeURIComponent(query)}`;
            }
        });
        
        // ... other form bindings ...
    },
    
    // **REUSABLE HANDLERS**
    async handleAddToCart(productId, quantity = 1) {
        if (!this.State.user.isLoggedIn) {
            this.Toast.show('Please log in to add items to your cart.', 'error');
            this.UI.showModal('login');
            return;
        }
        try {
            const updatedCart = await this.API.updateCart(productId, quantity);
            this.State.setCart(updatedCart);
            this.UI.updateCart();
            this.Toast.show('Item added to cart!');
        } catch(error) {
            this.Toast.show(error.message, 'error');
        }
    },
    
    handleLogout() { /* ... same as script.js refactor ... */ },
    // ... etc. ...
};

// --- KICK OFF THE APPLICATION ---
App.init();