document.addEventListener('DOMContentLoaded', () => {
    // --- 1. SETUP ---
    const API_BASE_URL = 'http://localhost:5000';
    const getElement = (id) => document.getElementById(id);
    const tableBody = getElement('orders-tbody');

    if (!tableBody) {
        // This stops the script if it's not on the admin orders page
        return;
    }

    // --- 2. SECURITY CHECK ---
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (!userInfo || !userInfo.isAdmin) {
        alert('Access Denied. You must be an administrator.');
        window.location.href = '/index.html';
        return;
    }
    const token = userInfo.token;
    if (!token) {
        alert('Authentication error. Please log in again.');
        window.location.href = '/index.html';
        return;
    }

    // --- 3. NEW FUNCTION TO LOAD DASHBOARD STATS ---
    async function loadDashboardStats() {
        try {
            const stats = await fetch(`${API_BASE_URL}/api/dashboard/stats`, {
                headers: { 'Authorization': `Bearer ${token}` }
            }).then(res => res.json());

            getElement('total-products').textContent = stats.totalProducts;
            getElement('total-users').textContent = stats.totalUsers;
            getElement('orders-today').textContent = stats.ordersToday;
            getElement('total-sales').textContent = `₹${stats.totalSales.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        } catch (error) {
            console.error('Failed to load dashboard stats:', error);
            document.querySelectorAll('.dashboard-stats p').forEach(p => p.textContent = 'Error');
        }
    }

    // --- 4. FUNCTION TO LOAD ORDERS (your existing logic) ---
    async function loadOrders() {
        try {
            const response = await fetch(`${API_BASE_URL}/api/orders/all`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!response.ok) throw new Error('Could not load orders.');
            const orders = await response.json();
            
            tableBody.innerHTML = '';
            if (orders.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="6">No orders found.</td></tr>`;
                return;
            }

            orders.forEach(order => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${order._id}</td>
                    <td>${order.user ? order.user.name : 'N/A'}</td>
                    <td>${new Date(order.createdAt).toLocaleDateString()}</td>
                    <td>₹${order.totalPrice.toFixed(2)}</td>
                    <td>${order.isPaid ? 'Yes' : 'No'}</td>
                    <td>
                        <select class="status-dropdown" data-order-id="${order._id}">
                            <option value="Preparing" ${order.status === 'Preparing' ? 'selected' : ''}>Preparing</option>
                            <option value="Shipped" ${order.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
                            <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                            <option value="Canceled" ${order.status === 'Canceled' ? 'selected' : ''}>Canceled</option>
                        </select>
                    </td>
                `;
                tableBody.appendChild(row);
            });

            // Re-attach event listeners for the new dropdowns
            attachDropdownListeners();
        } catch (error) {
            console.error('Failed to load orders:', error);
            tableBody.innerHTML = `<tr><td colspan="6">${error.message}</td></tr>`;
        }
    }

    // --- 5. FUNCTION TO ATTACH DROPDOWN LISTENERS ---
    function attachDropdownListeners() {
        document.querySelectorAll('.status-dropdown').forEach(dropdown => {
            let originalStatus = dropdown.value;
            dropdown.addEventListener('focus', () => { originalStatus = dropdown.value; });
            dropdown.addEventListener('change', async (e) => {
                const orderId = e.target.dataset.orderId;
                const newStatus = e.target.value;
                if (!confirm(`Are you sure you want to change status to "${newStatus}"?`)) {
                    e.target.value = originalStatus;
                    return;
                }
                try {
                    await fetch(`${API_BASE_URL}/api/orders/${orderId}/status`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify({ status: newStatus })
                    });
                    alert('Status updated successfully!');
                    originalStatus = newStatus;
                } catch (err) {
                    alert(`Error: Could not update status.`);
                    e.target.value = originalStatus;
                }
            });
        });
    }

    // --- 6. INITIALIZE PAGE ---
    // Load both stats and orders when the page loads
    loadDashboardStats();
    loadOrders();
});