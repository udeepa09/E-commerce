import React from 'react';
import { useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { removeFromCart, updateCartQuantity } from '../actions/cartActions';
import './CartItem.css';

const CartItem = ({ item }) => {
    const dispatch = useDispatch();

    const removeFromCartHandler = (id) => {
        // Dispatch the action to remove the item from the cart state.
        dispatch(removeFromCart(id));
    };
    
    // Future enhancement: handler for quantity changes
    // const handleQuantityChange = (id, qty) => {
    //     dispatch(updateCartQuantity(id, qty));
    // }

    return (
        <div className="cart-item">
            <div className="cart-item__image">
                <img src={item.image} alt={item.name} />
            </div>
            <div className="cart-item__details">
                <Link to={`/product/${item.product}`} className="cart-item__name">
                    {item.name}
                </Link>
                <p className="cart-item__price">₹{item.price.toFixed(2)}</p>
                {/* Quantity selector would go here */}
                <p className="cart-item__quantity">Qty: {item.quantity}</p>
            </div>
            <div className="cart-item__actions">
                 <p className="cart-item__total-price">
                    Total: ₹{(item.quantity * item.price).toFixed(2)}
                </p>
                <button
                    type="button"
                    className="btn-remove"
                    onClick={() => removeFromCartHandler(item.product)}
                    aria-label={`Remove ${item.name} from cart`}
                >
                    Remove
                </button>
            </div>
        </div>
    );
};

export default CartItem;