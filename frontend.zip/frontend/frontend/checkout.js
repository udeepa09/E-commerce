// checkout.js
document.addEventListener('DOMContentLoaded', async () => {
    let userInfo, token, cart = [], shippingAddress, paymentMethod = 'CashOnDelivery';
    let appliedCoupon = JSON.parse(localStorage.getItem('appliedCoupon')); // READ

    const API_BASE_URL = 'http://127.0.0.1:5000';
    const getElement = id => document.getElementById(id);
    const elements = {
        summaryItems: getElement('cart-summary-items'),
        summaryTotal: getElement('cart-summary-total'),
        shippingForm: getElement('shipping-form'),
        paymentContinueBtn: getElement('payment-continue-btn'),
        placeOrderBtn: getElement('place-order-btn'),
        summaryDetails: getElement('summary-details')
    };

    const showStep = (stepId) => {
        document.querySelectorAll('.checkout-step').forEach(step => step.classList.remove('active'));
        getElement(stepId).classList.add('active');
    };

    const fetchAPI = async (url, options = {}) => {
        const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };
        const res = await fetch(url, { ...options, headers });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message);
        return data;
    };

    const renderCartSummary = () => {
        if (!cart || cart.length === 0) return;
        elements.summaryItems.innerHTML = cart.map(item => `<div class="summary-item"><span>${item.product.name} (x${item.quantity})</span><span>₹${(item.product.price * item.quantity).toFixed(2)}</span></div>`).join('');
        const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
        let discount = 0;
        if (appliedCoupon) {
            if (appliedCoupon.discountType === 'Percentage') discount = subtotal * appliedCoupon.discountValue / 100;
            else discount = appliedCoupon.discountValue;
        }
        const grandTotal = subtotal - discount;
        elements.summaryTotal.innerHTML = `<span>Total</span><span>₹${grandTotal.toFixed(2)}</span>`;
    };

    elements.shippingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        shippingAddress = { address: getElement('address').value, city: getElement('city').value, postalCode: getElement('postalCode').value };
        localStorage.setItem('shippingAddress', JSON.stringify(shippingAddress));
        showStep('payment-step');
    });

    elements.paymentContinueBtn.addEventListener('click', () => {
        paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
        elements.summaryDetails.innerHTML = `<h4>Shipping Address:</h4><p>${shippingAddress.address}, ${shippingAddress.city}, ${shippingAddress.postalCode}</p><h4>Payment Method:</h4><p>${paymentMethod}</p>`;
        showStep('summary-step');
    });

    elements.placeOrderBtn.addEventListener('click', async () => {
        elements.placeOrderBtn.disabled = true;
        elements.placeOrderBtn.textContent = 'Placing Order...';
        const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
        let discount = 0;
        if (appliedCoupon) {
            if (appliedCoupon.discountType === 'Percentage') discount = subtotal * appliedCoupon.discountValue / 100;
            else discount = appliedCoupon.discountValue;
        }
        const finalTotalPrice = subtotal - discount;
        const orderData = {
            orderItems: cart.map(item => ({ name: item.product.name, quantity: item.quantity, image: item.product.image, price: item.product.price, product: item.product._id })),
            shippingAddress, paymentMethod, totalPrice: finalTotalPrice
        };
        try {
            await fetchAPI(`${API_BASE_URL}/api/orders`, { method: 'POST', body: JSON.stringify(orderData) });
            localStorage.removeItem('appliedCoupon'); // CLEAR
            await fetchAPI(`${API_BASE_URL}/api/users/cart/clear`, { method: 'DELETE' });
            showStep('confirmation-step');
        } catch (e) {
            alert(`Failed to place order: ${e.message}`);
            elements.placeOrderBtn.disabled = false;
            elements.placeOrderBtn.textContent = 'Place Order';
        }
    });

    const init = async () => {
        const storedUserInfo = localStorage.getItem('userInfo');
        if (!storedUserInfo) { window.location.href = '/login.html'; return; }
        userInfo = JSON.parse(storedUserInfo);
        token = userInfo.token;
        shippingAddress = JSON.parse(localStorage.getItem('shippingAddress')) || {};
        getElement('address').value = shippingAddress.address || '';
        getElement('city').value = shippingAddress.city || '';
        getElement('postalCode').value = shippingAddress.postalCode || '';
        try {
            cart = await fetchAPI(`${API_BASE_URL}/api/users/cart`);
            renderCartSummary();
            showStep('shipping-step');
        } catch (e) { document.querySelector('.checkout-page').innerHTML = `<h1>Error</h1><p>Could not load cart.</p>`; }
    };
    init();
});