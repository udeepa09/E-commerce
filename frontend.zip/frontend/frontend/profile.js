// profile.js
document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const form = document.getElementById('profile-update-form');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const messageEl = document.getElementById('profile-message');
    
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    // Security: If not logged in, redirect to homepage
    if (!userInfo || !userInfo.token) {
        window.location.href = '/index.html';
        return;
    }

    // --- 1. Load current user data into the form ---
    const loadUserProfile = async () => {
        try {
            const user = await fetch(`${API_BASE_URL}/api/users/profile`, {
                headers: { 'Authorization': `Bearer ${userInfo.token}` }
            }).then(res => res.json());
            
            nameInput.value = user.name;
            emailInput.value = user.email;
        } catch (error) {
            messageEl.textContent = 'Could not load your profile.';
            messageEl.className = 'message error';
        }
    };

    // --- 2. Handle the form submission to update the profile ---
    const handleProfileUpdate = async (e) => {
        e.preventDefault();
        messageEl.textContent = ''; // Clear previous messages
        
        // --- Validation ---
        if (passwordInput.value !== confirmPasswordInput.value) {
            messageEl.textContent = 'Passwords do not match.';
            messageEl.className = 'message error';
            return;
        }
        
        const updateData = {
            name: nameInput.value,
            email: emailInput.value,
        };

        // Only include the password in the request if the user entered one
        if (passwordInput.value) {
            updateData.password = passwordInput.value;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/users/profile`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userInfo.token}`
                },
                body: JSON.stringify(updateData)
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Failed to update profile.');
            }
            
            // --- Success ---
            messageEl.textContent = 'Profile updated successfully!';
            messageEl.className = 'message success';
            
            // IMPORTANT: Update localStorage with the new details
            const updatedUserInfo = { ...userInfo, name: data.name, email: data.email };
            localStorage.setItem('userInfo', JSON.stringify(updatedUserInfo));

            // Clear password fields after successful update
            passwordInput.value = '';
            confirmPasswordInput.value = '';

        } catch (error) {
            messageEl.textContent = error.message;
            messageEl.className = 'message error';
        }
    };

    // --- Attach event listener and load initial data ---
    form.addEventListener('submit', handleProfileUpdate);
    loadUserProfile();
});