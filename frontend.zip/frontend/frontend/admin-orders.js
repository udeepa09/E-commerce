// admin-orders.js
document.addEventListener('DOMContentLoaded', () => {
    // --- State and Elements ---
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    const token = userInfo ? userInfo.token : null;
    
    // New filter elements
    const nameSearchInput = document.getElementById('name-search-input');
    const searchBtn = document.getElementById('search-btn');
    const statusFilter = document.getElementById('status-filter');
    
    // --- Security Check ---
    if (!userInfo || !userInfo.isAdmin) { /* ... same as before ... */ }

    // --- MAIN FUNCTION to load the orders table ---
    const loadOrdersTable = async () => {
        const ordersTbody = document.getElementById('orders-tbody');
        ordersTbody.innerHTML = '<tr><td colspan="6">Loading...</td></tr>';

        // 1. Get current filter values
        const status = statusFilter.value;
        const name = nameSearchInput.value;

        // 2. Construct the API URL with query parameters
        const url = new URL(`${API_BASE_URL}/api/orders`);
        if (status) url.searchParams.append('status', status);
        if (name) url.searchParams.append('name', name);

        try {
            const orders = await fetch(url, {
                headers: { 'Authorization': `Bearer ${token}` }
            }).then(res => res.json());

            ordersTbody.innerHTML = '';
            if (orders.length === 0) {
                ordersTbody.innerHTML = '<tr><td colspan="6">No orders found matching your criteria.</td></tr>';
                return;
            }

            // 3. Render the filtered/searched orders
            orders.forEach(order => {
                // ... (your existing row creation logic is fine)
            });

        } catch (error) {
            ordersTbody.innerHTML = '<tr><td colspan="6">Could not load orders.</td></tr>';
        }
    };
    
    // ... (Your loadDashboardStats and handleStatusChange functions are fine) ...

    // --- NEW EVENT LISTENERS ---
    
    // When the status dropdown changes, reload the table
    statusFilter.addEventListener('change', loadOrdersTable);
    
    // When the search button is clicked, reload the table
    searchBtn.addEventListener('click', loadOrdersTable);

    // Optional: Allow pressing Enter in the search box
    nameSearchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            loadOrdersTable();
        }
    });

    // --- Initial Load ---
    // loadDashboardStats(); // Keep this if you have it
    loadOrdersTable(); // Initial load of all orders
});

// NOTE: You'll need to copy back in the full, working code for your `forEach(order => { ... })`
// rendering loop and your other functions like `loadDashboardStats` and `handleStatusChange`.