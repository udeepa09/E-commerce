// frontend/home.js
const HomePage = {
    selectors: {
        productGrid: document.getElementById('product-grid'),
        categoryFilters: document.getElementById('category-filters'),
    },

    init() {
        this.loadProducts();
        this.bindEvents();
    },

    async loadProducts() {
        const grid = this.selectors.productGrid;
        if (!grid) return;
        // Show a skeleton loader while fetching
        grid.innerHTML = '<p>Loading products...</p>';

        try {
            // Use the shared API from common.js
            const products = await window.App.API.getProducts();
            window.App.UI.renderProducts(products); // Use the shared renderer
        } catch (error) {
            grid.innerHTML = `<p class="error-message">Error: Could not connect to the server. Please ensure the backend is running.</p>`;
            console.error("Product fetch error:", error);
        }
    },

    bindEvents() {
        // Add any homepage-specific event listeners here
    }
};

// Wait for the common app to be ready before running page-specific logic
document.addEventListener('app-ready', () => {
    HomePage.init();
});