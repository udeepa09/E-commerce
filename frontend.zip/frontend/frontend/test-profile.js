document.addEventListener('DOMContentLoaded', () => {

    const profileBtn = document.getElementById('profile-btn');
    const profileDropdown = document.getElementById('profile-dropdown');

    if (profileBtn && profileDropdown) {
        // Add simple content to the dropdown
        profileDropdown.innerHTML = `<p>It works!</p>`;

        // When the profile button is clicked...
        profileBtn.addEventListener('click', (event) => {
            event.stopPropagation(); // This is important
            profileDropdown.classList.toggle('active');
        });
    }

    // This listener will close the dropdown if you click anywhere else
    document.addEventListener('click', (e) => {
        if (profileDropdown && profileDropdown.classList.contains('active')) {
            if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.classList.remove('active');
            }
        }
    });
});