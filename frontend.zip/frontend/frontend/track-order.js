// track-order.js
document.addEventListener('DOMContentLoaded', async () => {
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const params = new URLSearchParams(window.location.search);
    const orderId = params.get('id');

    if (!orderId) {
        document.querySelector('.tracker-container').innerHTML = '<h1>Error: No Order ID provided.</h1>';
        return;
    }

    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (!userInfo || !userInfo.token) {
        document.querySelector('.tracker-container').innerHTML = '<h1>Error: Not Authorized.</h1>';
        return;
    }

    try {
        const order = await fetch(`${API_BASE_URL}/api/orders/${orderId}`, {
            headers: { 'Authorization': `Bearer ${userInfo.token}` }
        }).then(res => res.json());

        // Populate summary
        document.getElementById('track-order-id').textContent = order._id;
        document.getElementById('track-order-status').textContent = order.status;

        // Update the progress bar based on the status
        const progressBar = document.getElementById('progress-bar');
        const stepProcessing = document.getElementById('step-processing');
        const stepShipped = document.getElementById('step-shipped');
        const stepDelivered = document.getElementById('step-delivered');

        if (order.status === 'Processing') {
            progressBar.style.width = '0%';
            stepProcessing.classList.add('active');
        } else if (order.status === 'Shipped') {
            progressBar.style.width = '50%';
            stepProcessing.classList.add('active');
            stepShipped.classList.add('active');
        } else if (order.status === 'Delivered') {
            progressBar.style.width = '100%';
            stepProcessing.classList.add('active');
            stepShipped.classList.add('active');
            stepDelivered.classList.add('active');
        }
        
    } catch (error) {
        document.querySelector('.tracker-container').innerHTML = `<h1>Error loading order details.</h1>`;
    }
});