document.addEventListener('DOMContentLoaded', async () => {
    // --- Configuration ---
    const ordersContainer = document.getElementById('orders-container');
    const API_BASE_URL = 'http://127.0.0.1:5000'; // Ensure this matches your backend port

    // --- Check if the main container exists on the page ---
    if (!ordersContainer) {
        console.error('Orders container with ID "orders-container" not found on this page.');
        return;
    }

    // --- 1. Get User Info & Handle Authentication ---
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    // If no user is logged in, display a message and stop execution.
    if (!userInfo || !userInfo.token) {
        ordersContainer.innerHTML = '<p>Please <a href="/login.html">log in</a> to see your order history.</p>';
        return;
    }

    // --- 2. Fetch and Render "My Orders" ---
    try {
        // Fetch orders from the backend, providing the user's token for authorization.
        const response = await fetch(`${API_BASE_URL}/api/orders/myorders`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${userInfo.token}`
            }
        });

        if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                 throw new Error('Your session may have expired. Please log in again.');
            }
            throw new Error('Could not load your orders at this time.');
        }
        
        const orders = await response.json();

        // --- 3. Render the Orders to the Page ---
        if (orders.length === 0) {
            ordersContainer.innerHTML = '<p>You have not placed any orders yet.</p>';
            return;
        }

        ordersContainer.innerHTML = ''; 

        orders.forEach(order => {
            const orderCard = document.createElement('div');
            orderCard.className = 'order-card';

            // --- Logic to create the delivery date string ---
            let deliveryInfoHtml = '';
            if (order.isDelivered && order.deliveredAt) {
                deliveryInfoHtml = `<p class="actual-delivery"><strong>Delivered on:</strong> <span>${new Date(order.deliveredAt).toLocaleDateString()}</span></p>`;
            } else if (order.status !== 'Canceled' && order.expectedDelivery) {
                deliveryInfoHtml = `<p class="expected-delivery"><strong>Expected by:</strong> <span>${new Date(order.expectedDelivery).toLocaleDateString()}</span></p>`;
            }

            // --- Generate the full HTML for the card, including the new "Track Order" button ---
            orderCard.innerHTML = `
                <div class="order-header">
                    <div class="order-details">
                        <p><strong>Order ID:</strong> <span>${order._id}</span></p>
                        <p><strong>Date:</strong> <span>${new Date(order.createdAt).toLocaleDateString()}</span></p>
                        <p><strong>Total:</strong> <span>₹${order.totalPrice.toFixed(2)}</span></p>
                        ${deliveryInfoHtml}
                    </div>

                    <div class="order-actions">
                        <div class="order-status">
                            <span class="status-badge status-${order.status.toLowerCase()}">${order.status}</span>
                        </div>
                        
                        <!-- NEWLY ADDED TRACK ORDER BUTTON -->
                        <a href="track-order.html?id=${order._id}" class="btn-track">
                            <i class="fas fa-truck"></i> Track Order
                        </a>
                        
                        <a href="invoice.html?id=${order._id}" target="_blank" class="btn-invoice">
                            <i class="fas fa-file-invoice"></i> Download Invoice
                        </a>
                    </div>
                </div>
                <div class="order-items">
                    ${order.orderItems.map(item => `
                        <div class="order-item">
                            <img src="${item.image}" alt="${item.name}">
                            <div class="item-info">
                                <span class="item-name">${item.name}</span>
                                <span class="item-qty">Quantity: ${item.quantity}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
            
            ordersContainer.appendChild(orderCard);
        });

    } catch (error) {
        ordersContainer.innerHTML = `<p style="color: red; text-align: center;">Error: ${error.message}</p>`;
        console.error('Failed to fetch orders:', error);
    }
});