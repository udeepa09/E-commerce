// invoice.js

document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://127.0.0.1:5000';

    // Get the order ID from the URL query parameter
    const params = new URLSearchParams(window.location.search);
    const orderId = params.get('id');

    if (!orderId) {
        document.body.innerHTML = '<h1>Error: No Order ID provided.</h1>';
        return;
    }

    // Get user token for authenticated request
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (!userInfo || !userInfo.token) {
        document.body.innerHTML = '<h1>Error: You are not authorized to view this page. Please log in.</h1>';
        return;
    }
    
    // --- MAIN FUNCTION TO GENERATE INVOICE ---
    const generateInvoice = async () => {
        try {
            // 1. Fetch the specific order details from the backend
            const order = await fetch(`${API_BASE_URL}/api/orders/${orderId}`, {
                headers: {
                    'Authorization': `Bearer ${userInfo.token}`
                }
            }).then(res => {
                if (!res.ok) throw new Error('Could not fetch order data.');
                return res.json();
            });

            // 2. Populate the HTML template with the fetched data
            document.getElementById('order-id').textContent = order._id;
            document.getElementById('order-date').textContent = new Date(order.createdAt).toLocaleDateString();
            document.getElementById('order-status').textContent = order.status;
            
            // Populate user and shipping details
            document.getElementById('user-details').innerHTML = `
                ${order.user.name}<br>
                ${order.shippingAddress.address}<br>
                ${order.shippingAddress.city}, ${order.shippingAddress.postalCode}<br>
                ${order.shippingAddress.country}
            `;
            
            // Populate table with order items
            const itemsTbody = document.getElementById('invoice-items');
            itemsTbody.innerHTML = ''; // Clear loading text
            order.orderItems.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>₹${item.price.toFixed(2)}</td>
                    <td>₹${(item.quantity * item.price).toFixed(2)}</td>
                `;
                itemsTbody.appendChild(row);
            });
            
            // Populate grand total
            document.getElementById('grand-total').textContent = `₹${order.totalPrice.toFixed(2)}`;
            
            // Update page title
            document.title = `Invoice - ${order._id}`;

            // 3. Use html2pdf.js to generate and download the PDF
            generatePdf();

        } catch (error) {
            document.body.innerHTML = `<h1>Error: ${error.message}</h1>`;
            console.error(error);
        }
    };
    
    const generatePdf = () => {
        const element = document.getElementById('invoice-to-print');
        const opt = {
          margin:       0.5,
          filename:     `invoice_${orderId}.pdf`,
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { scale: 2 },
          jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
        };

        // New Promise-based usage:
        html2pdf().set(opt).from(element).save();
    };

    // Run the main function
    generateInvoice();
});