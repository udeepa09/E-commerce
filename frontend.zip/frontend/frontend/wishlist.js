document.addEventListener('DOMContentLoaded', () => {
    const wishlistContainer = document.getElementById('wishlist-container');
    const API_BASE_URL = 'http://127.0.0.1:5000';

    if (!wishlistContainer) {
        console.error('Wishlist container not found on this page.');
        return;
    }

    // --- 1. SECURITY & AUTHENTICATION ---
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    // If no user is logged in, show a message and stop.
    if (!userInfo) {
        wishlistContainer.innerHTML = '<h2>My Wishlist</h2><p>Please <a href="/index.html">log in</a> to see your wishlist.</p>';
        return;
    }

    const token = userInfo.token;
    // If the user object is there but the token is missing, something is wrong.
    if (!token) {
        wishlistContainer.innerHTML = '<h2>My Wishlist</h2><p>Authentication error. Please <a href="/index.html">log in</a> again.</p>';
        return;
    }

    // --- 2. FETCH AND DISPLAY WISHLIST ---
    async function fetchAndDisplayWishlist() {
        try {
            // --- THE FIX IS HERE: Add the Authorization header ---
            const wishlistData = await fetch(`${API_BASE_URL}/api/users/wishlist`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(res => {
                if (!res.ok) {
                    throw new Error('Failed to fetch data from the server.');
                }
                return res.json();
            });

            // The backend sends { products: [...] }. We need the array.
            const wishlistItems = wishlistData.products || [];

            if (wishlistItems.length === 0) {
                wishlistContainer.innerHTML = '<h2>My Wishlist</h2><p>Your wishlist is empty. Start adding some products!</p>';
                return;
            }

            // Fetch full product details for each ID in the wishlist
            const productPromises = wishlistItems.map(productId =>
                fetch(`${API_BASE_URL}/api/products/${productId}`).then(res => res.json())
            );
            const products = await Promise.all(productPromises);
            
            // Render the products
            let productsHtml = '<h2>My Wishlist</h2><div class="product-grid">';
            products.forEach(product => {
                productsHtml += `
                    <div class="product-card">
                        <a href="/product-detail.html?id=${product._id}" class="product-link">
                            <img src="${product.image}" alt="${product.name}">
                            <div class="product-info">
                                <h3>${product.name}</h3>
                                <p class="price">₹${product.price.toLocaleString('en-IN')}</p>
                            </div>
                        </a>
                        <div class="product-info-footer">
                            <button class="remove-from-wishlist-btn" data-id="${product._id}">Remove</button>
                        </div>
                    </div>
                `;
            });
            productsHtml += '</div>';
            wishlistContainer.innerHTML = productsHtml;

        } catch (error) {
            wishlistContainer.innerHTML = `<h2>My Wishlist</h2><p>Could not load your wishlist. Please try again later.</p>`;
            console.error('Failed to load wishlist:', error);
        }
    }

    // --- 3. EVENT LISTENER FOR "REMOVE" BUTTONS ---
    wishlistContainer.addEventListener('click', async (e) => {
        if (e.target.classList.contains('remove-from-wishlist-btn')) {
            const productId = e.target.dataset.id;
            if (!confirm('Are you sure you want to remove this item from your wishlist?')) {
                return;
            }
            try {
                // Send a POST request to the update endpoint (which toggles the item)
                await fetch(`${API_BASE_URL}/api/users/wishlist`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ productId })
                });

                // Refresh the wishlist to show the item has been removed
                fetchAndDisplayWishlist();
            } catch (error) {
                alert('Failed to remove item from wishlist.');
                console.error('Wishlist removal error:', error);
            }
        }
    });

    // --- 4. INITIALIZE THE PAGE ---
    fetchAndDisplayWishlist();
});