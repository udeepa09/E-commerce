// shop.js

document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const productGrid = document.getElementById('product-grid');
    const sortSelect = document.getElementById('sort-select');
    const paginationControls = document.getElementById('pagination-controls');

    if (!productGrid || !sortSelect || !paginationControls) {
        return; 
    }

    let currentPage = 1;
    let currentSort = 'createdAt-desc';

    const loadShopProducts = async () => {
        productGrid.innerHTML = '<p>Loading products...</p>';
        paginationControls.innerHTML = '';
        
        
         const url = new URL(`${API_BASE_URL}/api/products/shop`);
        url.searchParams.append('pageNumber', currentPage);
        url.searchParams.append('sort', currentSort);

        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`Server error: ${response.statusText}`);
            const data = await response.json();

            // This defensive check prevents crashes.
            const products = data.products || [];
            const page = data.page || 1;
            const pages = data.pages || 1;

            productGrid.innerHTML = ''; 

            if (products.length === 0) {
                productGrid.innerHTML = '<p>No products found matching your criteria.</p>';
            } else {
                products.forEach(product => {
                    const productCard = document.createElement('div');
                    productCard.className = 'product-card';
                    productCard.innerHTML = `
                        <button class="add-to-wishlist-btn" data-id="${product._id}"><i class="fas fa-heart"></i></button>
                        <a href="product-detail.html?id=${product._id}" class="product-link">
                            <img src="${product.image}" alt="${product.name}">
                            <div class="product-info">
                                <h3>${product.name}</h3>
                                <p class="price">₹${product.price.toLocaleString('en-IN')}</p>
                            </div>
                        </a>
                        <div class="product-info-footer">
                            <button class="add-to-cart-btn" data-id="${product._id}">Add to Cart</button>
                        </div>
                    `;
                    productGrid.appendChild(productCard);
                });
            }
            renderPagination(page, pages);
        } catch (error) {
            productGrid.innerHTML = `<p style="color: red;">${error.message}</p>`;
            console.error(error);
        }
    };

    const renderPagination = (currentPage, totalPages) => {
        if (totalPages <= 1) {
            paginationControls.innerHTML = '';
            return;
        }
        paginationControls.innerHTML = `
            <button class="pagination-btn" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}>« Prev</button>
            <span>Page ${currentPage} of ${totalPages}</span>
            <button class="pagination-btn" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}>Next »</button>
        `;
    };

    sortSelect.addEventListener('change', () => {
        currentSort = sortSelect.value;
        currentPage = 1;
        loadShopProducts();
    });

    paginationControls.addEventListener('click', (e) => {
        const btn = e.target.closest('.pagination-btn');
        if (btn && !btn.disabled) {
            currentPage = Number(btn.dataset.page);
            loadShopProducts();
        }
    });

    loadShopProducts();
});