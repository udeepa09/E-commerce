document.addEventListener('DOMContentLoaded', () => {
    // --- Configuration ---
    const API_BASE_URL = 'http://127.0.0.1:5000'; // Make sure this is your backend's address

    // --- DOM Elements ---
    const container = document.getElementById('product-detail-container');
    const reviewsList = document.getElementById('reviews-list');
    const reviewFormWrapper = document.getElementById('review-form-wrapper');

    // --- Application State ---
    let productData = null;
    let userInfo = null;

    // --- Get Product ID from URL ---
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');

    // --- Helper to get user info from localStorage ---
    const getUserInfo = () => {
        const storedUserInfo = localStorage.getItem('userInfo');
        userInfo = storedUserInfo ? JSON.parse(storedUserInfo) : null;
    };

    // ==========================================================
    //  EVENT DELEGATION: This one listener handles all clicks
    // ==========================================================
    document.querySelector('main.container').addEventListener('click', (e) => {
        const cartButton = e.target.closest('#detail-add-to-cart');
        const wishlistButton = e.target.closest('#detail-add-to-wishlist');

        if (cartButton) {
            e.preventDefault();
            handleAddToCart(cartButton);
        }

        if (wishlistButton) {
            e.preventDefault();
            handleAddToWishlist(wishlistButton);
        }
    });

    // --- FETCHES AND RENDERS THE MAIN PRODUCT INFO ---
    const fetchProductDetails = async () => {
        if (!productId) { return; }
        try {
            const product = await fetch(`${API_BASE_URL}/api/products/${productId}`).then(res => {
                if (!res.ok) throw new Error('Product not found');
                return res.json();
            });
            
            productData = product;
            document.title = `${product.name} - ShopMate`;
            
            container.innerHTML = `
                <div class="product-image-section">
                    <img src="${product.image}" alt="${product.name}">
                </div>
                <div class="product-info-section">
                    <h1>${product.name}</h1>
                    <div class="rating">
                        <span>${'★'.repeat(Math.round(product.rating))}${'☆'.repeat(5 - Math.round(product.rating))}</span>
                        <span class="num-reviews">(${product.numReviews} reviews)</span>
                    </div>
                    <p class="price">₹${product.price.toLocaleString('en-IN')}</p>
                    <p class="description">${product.description || 'No description available.'}</p>
                    <div class="product-detail-actions">
                        <button class="btn btn-primary" id="detail-add-to-cart">Add to Cart</button>
                        <button class="btn btn-secondary" id="detail-add-to-wishlist">Add to Wishlist</button>
                    </div>
                </div>
            `;
        } catch (error) {
            container.innerHTML = `<p class="empty-msg">Oops! Could not load product details.</p>`;
        }
    };

    // --- ADD TO CART HANDLER ---
    const handleAddToCart = async (btn) => {
        if (!userInfo) { alert('Please log in to add items to your cart.'); return; }
        if (!productData) { alert('Product data is not loaded yet.'); return; }
        
        btn.textContent = 'Adding...';
        btn.disabled = true;

        try {
            const response = await fetch(`${API_BASE_URL}/api/users/cart`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${userInfo.token}` },
                body: JSON.stringify({ productId: productData._id, quantity: 1 })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: 'An unknown error occurred.' }));
                throw new Error(errorData.message);
            }

            btn.textContent = 'Added to Cart!';
            // The button will re-enable if the user reloads the page. This is fine.

        } catch (error) {
            alert(`Failed to add to cart: ${error.message}`);
            btn.textContent = 'Add to Cart';
            btn.disabled = false;
        }
    };
    
    // --- ADD TO WISHLIST HANDLER ---
    const handleAddToWishlist = async (btn) => {
        // Implement similar logic as handleAddToCart
    };

    // ======================================================
    //  FULL REVIEW FUNCTIONS (INCLUDED)
    // ======================================================
    const fetchAndDisplayReviews = async () => {
        if (!productId) return;
        try {
            const response = await fetch(`${API_BASE_URL}/api/products/${productId}/reviews`);
            const reviews = await response.json();

            let userHasReviewed = false;
            if (userInfo && reviews.length > 0) {
                userHasReviewed = reviews.some(review => review.user && review.user._id === userInfo._id);
            }

            renderReviewForm(userHasReviewed);

            reviewsList.innerHTML = ''; 
            if (reviews.length === 0) {
                reviewsList.innerHTML = '<p>No reviews yet. Be the first to review!</p>';
            } else {
                reviews.forEach(review => {
                    const reviewElement = document.createElement('div');
                    reviewElement.className = 'review-item';
                    reviewElement.innerHTML = `
                        <strong>${review.user ? review.user.name : 'Anonymous'}</strong>
                        <div class="rating">${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</div>
                        <p class="comment">${review.comment}</p>
                        <small class="date">${new Date(review.createdAt).toLocaleDateString()}</small>
                    `;
                    reviewsList.appendChild(reviewElement);
                });
            }
        } catch (error) {
            reviewsList.innerHTML = '<p>Could not load reviews.</p>';
        }
    };

    const renderReviewForm = (userHasReviewed) => {
        if (!userInfo) {
            reviewFormWrapper.innerHTML = '<p>Please <a href="/login.html">log in</a> to write a review.</p>';
        } else if (userHasReviewed) {
            reviewFormWrapper.innerHTML = '<p class="message success">Thank you for your review!</p>';
        } else {
            reviewFormWrapper.innerHTML = `
                <form id="review-form">
                    <div class="form-group">
                        <label for="rating-select">Rating</label>
                        <select id="rating-select" required>
                            <option value="">Select...</option><option value="5">5 - Excellent</option><option value="4">4 - Very Good</option><option value="3">3 - Good</option><option value="2">2 - Fair</option><option value="1">1 - Poor</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="comment-textarea">Comment</label>
                        <textarea id="comment-textarea" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Review</button>
                    <div id="review-message" class="message"></div>
                </form>
            `;
            // Attach the submit listener directly to the form we just created
            document.getElementById('review-form').addEventListener('submit', handleReviewSubmit);
        }
    };

    const handleReviewSubmit = async (e) => {
        e.preventDefault();
        const rating = document.getElementById('rating-select').value;
        const comment = document.getElementById('comment-textarea').value;
        const messageDiv = document.getElementById('review-message');

        try {
            const response = await fetch(`${API_BASE_URL}/api/products/${productId}/reviews`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${userInfo.token}` },
                body: JSON.stringify({ rating, comment }),
            });
            const data = await response.json();
            if (!response.ok) { throw new Error(data.message); }
            
            // On success, simply re-fetch the reviews.
            // This will automatically re-render the list and the form area.
            fetchAndDisplayReviews();
            // Also re-fetch product details to update the average rating display
            fetchProductDetails();
        } catch (error) {
            messageDiv.textContent = error.message;
            messageDiv.className = 'message error';
        }
    };

    // --- INITIAL PAGE LOAD SEQUENCE ---
    const initializePage = async () => {
        getUserInfo();
        await fetchProductDetails();
        await fetchAndDisplayReviews();
    };

    initializePage();
});