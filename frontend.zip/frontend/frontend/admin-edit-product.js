// CORRECT admin-edit-product.js

document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const form = document.getElementById('edit-product-form');
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    
    // THIS LOGIC BELONGS HERE
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');

    if (!userInfo || !userInfo.isAdmin) {
        alert('Access Denied.');
        window.location.href = '/login.html';
        return;
    }
    // THIS IS THE CHECK THAT WAS CAUSING YOUR ERROR
    if (!productId) {
        alert('No product ID specified.');
        window.location.href = 'admin-products.html';
        return;
    }

    // --- Function to load product data into the form ---
    const loadProductData = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/api/products/${productId}`);
            if (!response.ok) throw new Error('Could not fetch product data.');
            const product = await response.json();

            document.getElementById('name').value = product.name;
            document.getElementById('price').value = product.price;
            document.getElementById('image').value = product.image;
            document.getElementById('brand').value = product.brand;
            document.getElementById('category').value = product.category;
            document.getElementById('countInStock').value = product.countInStock;
            document.getElementById('description').value = product.description;

        } catch (error) {
            alert(error.message);
        }
    };

    // --- Function to handle form submission for update ---
    const handleUpdate = async (e) => {
        e.preventDefault();
        const updatedProduct = {
            name: document.getElementById('name').value,
            price: document.getElementById('price').value,
            image: document.getElementById('image').value,
            brand: document.getElementById('brand').value,
            category: document.getElementById('category').value,
            countInStock: document.getElementById('countInStock').value,
            description: document.getElementById('description').value,
        };

        try {
            const response = await fetch(`${API_BASE_URL}/api/products/${productId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${userInfo.token}` },
                body: JSON.stringify(updatedProduct)
            });
            if (!response.ok) throw new Error('Failed to update product.');
            alert('Product updated successfully!');
            window.location.href = 'admin-products.html';
        } catch (error) {
            alert(error.message);
        }
    };

    form.addEventListener('submit', handleUpdate);

    loadProductData();
});