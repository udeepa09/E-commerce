// CORRECT admin-products.js

document.addEventListener('DOMContentLoaded', () => {
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const tableBody = document.getElementById('products-table-body');
    const createProductBtn = document.getElementById('create-product-btn');
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));

    // --- Security Check: Ensure user is an admin ---
    if (!userInfo || !userInfo.isAdmin) {
        alert('Access Denied: You must be an admin to view this page.');
        window.location.href = '/login.html';
        return;
    }

    // --- Function to fetch and display all products ---
    const loadProducts = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/api/products`);
            if (!response.ok) throw new Error('Failed to fetch products.');
            const products = await response.json();

            tableBody.innerHTML = ''; // Clear loading text
            products.forEach(product => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${product._id}</td>
                    <td>${product.name}</td>
                    <td>₹${product.price}</td>
                    <td>${product.category}</td>
                    <td>${product.brand}</td>
                    <td class="action-buttons">
                        <a href="admin-edit-product.html?id=${product._id}" class="btn-edit"><i class="fas fa-edit"></i></a>
                        <button class="btn-delete" data-id="${product._id}"><i class="fas fa-trash"></i></button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        } catch (error) {
            tableBody.innerHTML = `<tr><td colspan="6" class="error-text">${error.message}</td></tr>`;
        }
    };

    // --- Function to handle product deletion ---
    const deleteProduct = async (productId) => {
        if (!confirm('Are you sure you want to delete this product?')) return;
        try {
            const response = await fetch(`${API_BASE_URL}/api/products/${productId}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${userInfo.token}` }
            });
            if (!response.ok) throw new Error('Failed to delete product.');
            alert('Product deleted successfully!');
            loadProducts(); // Refresh the list
        } catch (error) {
            alert(error.message);
        }
    };

    // --- Function to handle product creation ---
    const createProduct = async () => {
        if (!confirm('This will create a new sample product. Continue?')) return;
        try {
            const response = await fetch(`${API_BASE_URL}/api/products`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${userInfo.token}` }
            });
            if (!response.ok) throw new Error('Failed to create product.');
            const createdProduct = await response.json();
            window.location.href = `admin-edit-product.html?id=${createdProduct._id}`;
        } catch (error) {
            alert(error.message);
        }
    };

    // --- Event Listeners ---
    tableBody.addEventListener('click', (e) => {
        const deleteBtn = e.target.closest('.btn-delete');
        if (deleteBtn) {
            deleteProduct(deleteBtn.dataset.id);
        }
    });
    
    createProductBtn.addEventListener('click', createProduct);

    // --- Initial Load ---
    loadProducts();
});