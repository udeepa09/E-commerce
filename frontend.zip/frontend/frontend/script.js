document.addEventListener('DOMContentLoaded', () => {
    // --- 1. GLOBAL STATE & ELEMENTS ---
    let allProducts = [];
    const userState = {
        isLoggedIn: false, name: null, cart: [], wishlist: [], shippingAddress: {}
    };
    const getElement = (id) => document.getElementById(id);
    const API_BASE_URL = 'http://127.0.0.1:5000';
    const productGrid = getElement('product-grid');
    const searchInput = getElement('search-input');
    const categoryFilters = getElement('category-filters');
    const cartCountSpan = getElement('cart-count');
    const wishlistCountSpan = getElement('wishlist-count');
    const profileBtn = getElement('profile-btn');
    const profileDropdown = getElement('profile-dropdown');
    const cartBtn = getElement('cart-btn');
    const cartSidebar = getElement('cart-sidebar');
    const closeCartBtn = getElement('close-cart-btn');
    const cartItemsContainer = getElement('cart-items-container');
    const cartSubtotalPrice = getElement('cart-subtotal-price');
    const checkoutBtn = getElement('checkout-btn');
    const modalBackdrop = getElement('modal-backdrop');
    const registerModal = getElement('register-modal');
    const loginModal = getElement('login-modal');
    const registerForm = getElement('register-form');
    const loginForm = getElement('login-form');
    const closeRegisterBtn = getElement('close-register');
    const closeLoginBtn = getElement('close-login');
    const continueToPaymentBtn = getElement('continue-to-payment-btn');
    const confirmOrderBtn = getElement('confirm-order-btn');
    const continueShoppingBtn = getElement('continue-shopping-btn');
    const backToCartBtns = document.querySelectorAll('.back-to-cart-btn');

    // --- 2. CORE API FUNCTION ---
    async function fetchAPI(url, options = {}) {
        options.credentials = 'include';
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if (userInfo && userInfo.token) {
            options.headers = { ...options.headers, 'Authorization': `Bearer ${userInfo.token}` };
        }
        try {
            const response = await fetch(url, options);
            if (response.status === 204) return null;
            const text = await response.text();
            const data = text ? JSON.parse(text) : {};
            if (!response.ok) { throw new Error(data.message || 'An API error occurred.'); }
            return data;
        } catch (error) { console.error(`API Error on ${url}:`, error); throw error; }
    }

    // --- 3. VIEW MANAGEMENT ---
    function showCartView(viewId) { document.querySelectorAll('.cart-view').forEach(v => v.classList.remove('active-view')); const view = getElement(viewId); if (view) view.classList.add('active-view'); }
    function closeAll() { if (modalBackdrop) modalBackdrop.style.display = 'none'; if (registerModal) registerModal.style.display = 'none'; if (loginModal) loginModal.style.display = 'none'; if (cartSidebar) cartSidebar.classList.remove('open'); if (profileDropdown) profileDropdown.classList.remove('active'); setTimeout(() => showCartView('cart-view'), 400); }
    function openRegisterModal() { closeAll(); if (modalBackdrop) modalBackdrop.style.display = 'block'; if (registerModal) registerModal.style.display = 'block'; }
    function openLoginModal() { closeAll(); if (modalBackdrop) modalBackdrop.style.display = 'block'; if (loginModal) loginModal.style.display = 'block'; }
    function openCartSidebar() { closeAll(); renderCartItems(); if (cartSidebar) cartSidebar.classList.add('open'); if (modalBackdrop) modalBackdrop.style.display = 'block'; }

    // --- 4. AUTHENTICATION ---
    async function handleAuth(formType, url, body) {
        const errorElement = (formType === 'register') ? getElement('register-error') : getElement('login-error');
        if (errorElement) errorElement.textContent = '';
        try {
            const data = await fetchAPI(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
            if (data) { 
                localStorage.setItem('userInfo', JSON.stringify(data)); 
                await checkLoginStatus();
                if (data.isAdmin) {
                    window.location.href = '/admin-orders.html';
                } else {
                    closeAll();
                }
            }
        } catch (error) { if (errorElement) errorElement.textContent = error.message; }
    }
    async function handleLogout() {
        try { await fetchAPI(`${API_BASE_URL}/api/users/logout`, { method: 'POST' }); localStorage.removeItem('userInfo'); await checkLoginStatus(); }
        catch (error) { console.error('Logout failed:', error); }
    }
    async function checkLoginStatus() {
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if (userInfo && userInfo.name) {
            userState.isLoggedIn = true; userState.name = userInfo.name;
            try {
                const [cartData, wishlistData] = await Promise.all([ fetchAPI(`${API_BASE_URL}/api/users/cart`), fetchAPI(`${API_BASE_URL}/api/users/wishlist`) ]);
                userState.cart = cartData || []; userState.wishlist = wishlistData ? wishlistData.products : [];
            } catch (error) { console.error("Session expired or token is invalid. Logging out."); await handleLogout(); return; }
        } else {
            userState.isLoggedIn = false; userState.name = null; userState.cart = []; userState.wishlist = [];
        }
        updateUI();
    }

    // --- 5. RENDERING & UI UPDATES ---
    function updateUI() { updateProfileDropdown(); updateCartCount(); updateWishlistCounter(); renderProducts(allProducts); }
    // In your main script.js file

function updateProfileDropdown() {
    if (!profileDropdown) return;
    profileDropdown.innerHTML = ''; // Clear previous content

    if (userState.isLoggedIn) {
        // --- THIS IS THE SECTION TO UPDATE ---
        let dropdownContent = `
            <h4>Hello, ${userState.name}</h4>
            
            <!-- ADD THIS NEW LINK TO THE PROFILE PAGE -->
            <a href="profile.html" class="dropdown-link">My Profile</a>
            
            <a href="orders.html" class="dropdown-link">My Orders</a>
        `;
        
        // Check if the user is an admin and add the Admin Panel link
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if (userInfo && userInfo.isAdmin) {
            dropdownContent += `<a href="admin-orders.html" class="dropdown-link admin-link">Admin Panel</a>`;
        }

        // Add the logout button
        dropdownContent += `<button id="logout-btn" class="logout-btn">Logout</button>`;
        profileDropdown.innerHTML = dropdownContent;

        // Re-attach event listeners
        const logoutBtn = getElement('logout-btn');
        if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);

    } else {
        // This is the view for logged-out users (unchanged)
        profileDropdown.innerHTML = `
            <h4>Welcome!</h4>
            <p>Log in or create an account.</p>
            <button id="login-btn-dropdown">Login</button>
            <button id="signup-btn-dropdown">Sign Up</button>
        `;

        // Re-attach event listeners
        const loginBtn = getElement('login-btn-dropdown');
        const signupBtn = getElement('signup-btn-dropdown');
        if (loginBtn) loginBtn.addEventListener('click', openLoginModal);
        if (signupBtn) signupBtn.addEventListener('click', openRegisterModal);
    }
}
    function renderProducts(productsToRender) { if (!productGrid) return; productGrid.innerHTML = ''; if (!productsToRender || productsToRender.length === 0) { productGrid.innerHTML = '<p style="text-align:center; grid-column: 1 / -1;">No products found.</p>'; return; } productsToRender.forEach(product => { const isInWishlist = userState.wishlist.some(item => item === product._id); productGrid.innerHTML += `<div class="product-card" data-id="${product._id}"><button class="add-to-wishlist-btn ${isInWishlist ? 'in-wishlist' : ''}" data-id="${product._id}"><i class="fas fa-heart"></i></button><a href="product-detail.html?id=${product._id}" class="product-link"><img src="${product.image}" alt="${product.name}"><div class="product-info"><h3>${product.name}</h3><p class="price">₹${product.price.toLocaleString('en-IN')}</p></div></a><div class="product-info-footer"><button class="add-to-cart-btn" data-id="${product._id}">Add to Cart</button></div></div>`; }); }
    function renderCartItems() { if (!cartItemsContainer) return; cartItemsContainer.innerHTML = ''; if (!userState.cart || userState.cart.length === 0) { cartItemsContainer.innerHTML = `<div class="cart-empty"><img src="https://cdni.iconscout.com/illustration/premium/thumb/empty-cart-4816550-4009094.png" alt="Empty Cart"><p>Your cart is empty!</p></div>`; if (cartSubtotalPrice) cartSubtotalPrice.textContent = '₹0.00'; if (checkoutBtn) checkoutBtn.disabled = true; return; } let subtotal = 0; userState.cart.forEach(item => { subtotal += item.price * item.quantity; cartItemsContainer.innerHTML += `<div class="cart-item" data-id="${item.product}"><img src="${item.image}" alt="${item.name}" class="cart-item-image"><div class="cart-item-details"><h4>${item.name}</h4><p class="price">₹${item.price.toLocaleString('en-IN')}</p><div class="quantity-controls"><button class="quantity-btn decrease-qty" data-id="${item.product}">-</button><span>${item.quantity}</span><button class="quantity-btn increase-qty" data-id="${item.product}">+</button></div></div></div>`; }); if (cartSubtotalPrice) cartSubtotalPrice.textContent = `₹${subtotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; if (checkoutBtn) checkoutBtn.disabled = false; }
    function updateCartCount() { if (!cartCountSpan) return; const totalItems = userState.cart.reduce((sum, item) => sum + item.quantity, 0); cartCountSpan.textContent = totalItems; cartCountSpan.style.display = totalItems > 0 ? 'flex' : 'none'; }
    function updateWishlistCounter() { if (!wishlistCountSpan) return; const totalItems = userState.wishlist.length; wishlistCountSpan.textContent = totalItems; wishlistCountSpan.style.display = totalItems > 0 ? 'flex' : 'none'; }

    // --- 6. EVENT LISTENERS ---
    if (profileBtn) profileBtn.addEventListener('click', (e) => { e.stopPropagation(); profileDropdown.classList.toggle('active'); });
    if (cartBtn) cartBtn.addEventListener('click', openCartSidebar);
    [closeRegisterBtn, closeLoginBtn, closeCartBtn, modalBackdrop].forEach(btn => { if (btn) btn.addEventListener('click', closeAll); });
    if (registerForm) registerForm.addEventListener('submit', (e) => { e.preventDefault(); handleAuth('register', `${API_BASE_URL}/api/users/register`, { name: getElement('register-name').value, email: getElement('register-email').value, password: getElement('register-password').value }); });
    if (loginForm) loginForm.addEventListener('submit', (e) => { e.preventDefault(); handleAuth('login', `${API_BASE_URL}/api/users/login`, { email: getElement('login-email').value, password: getElement('login-password').value }); });
    if (searchInput) searchInput.addEventListener('input', (e) => { renderProducts(allProducts.filter(p => p.name.toLowerCase().includes(e.target.value.toLowerCase()))); });
    if (categoryFilters) categoryFilters.addEventListener('click', (e) => { if (e.target.tagName !== 'BUTTON') return; const category = e.target.dataset.category; document.querySelectorAll('#category-filters button').forEach(btn => btn.classList.remove('active')); e.target.classList.add('active'); renderProducts(category === 'All' ? allProducts : allProducts.filter(p => p.category === category)); });
    if (checkoutBtn) checkoutBtn.addEventListener('click', () => showCartView('address-view'));
    
    // --- THIS IS THE CORRECTED SECTION ---
    if (continueToPaymentBtn) {
        continueToPaymentBtn.addEventListener('click', () => {
            userState.shippingAddress = {
                address: getElement('address').value,
                city: getElement('city').value,
                postalCode: getElement('postalCode').value
            };
            // Corrected to use 'userState' and the camelCase properties
            if (!userState.shippingAddress.address || !userState.shippingAddress.city || !userState.shippingAddress.postalCode) {
                alert('Please fill out all address fields.');
                return;
            }
            localStorage.setItem('shippingAddress', JSON.stringify(userState.shippingAddress));
            showCartView('payment-view');
        });
    }
    // ------------------------------------

    if (confirmOrderBtn) { confirmOrderBtn.addEventListener('click', async () => { confirmOrderBtn.disabled = true; confirmOrderBtn.textContent = 'Placing Order...'; try { const paymentMethod = document.querySelector('input[name="payment"]:checked').value; const orderData = { orderItems: userState.cart, shippingAddress: userState.shippingAddress, paymentMethod: paymentMethod, totalPrice: userState.cart.reduce((acc, item) => acc + item.price * item.quantity, 0) }; await fetchAPI(`${API_BASE_URL}/api/orders`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(orderData) }); userState.cart = []; updateUI(); showCartView('confirmed-view'); } catch (error) { alert('Failed to place order.'); console.error('Order placement error:', error); } confirmOrderBtn.disabled = false; confirmOrderBtn.textContent = 'Confirm Order'; }); }
    if (continueShoppingBtn) continueShoppingBtn.addEventListener('click', closeAll);
    if (backToCartBtns) backToCartBtns.forEach(btn => btn.addEventListener('click', () => showCartView('cart-view')));
    document.body.addEventListener('click', async (e) => {
        const button = e.target.closest('button');
        if (!button) return;
        if (button.classList.contains('add-to-cart-btn')) { if (!userState.isLoggedIn) { return openLoginModal(); } const productId = button.dataset.id; const existingItem = userState.cart.find(item => item.product === productId); const newQuantity = existingItem ? existingItem.quantity + 1 : 1; button.disabled = true; button.textContent = 'Adding...'; try { userState.cart = await fetchAPI(`${API_BASE_URL}/api/users/cart`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId, quantity: newQuantity }) }); updateCartCount(); openCartSidebar(); } catch (error) { console.error('Failed to add to cart'); } button.disabled = false; button.textContent = 'Add to Cart'; }
        if (button.classList.contains('add-to-wishlist-btn')) { if (!userState.isLoggedIn) { return openLoginModal(); } const productId = button.dataset.id; button.disabled = true; try { const updatedWishlist = await fetchAPI(`${API_BASE_URL}/api/users/wishlist`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId }) }); userState.wishlist = updatedWishlist.products || []; updateUI(); } catch (error) { console.error('Failed to update wishlist'); } button.disabled = false; }
        if (button.classList.contains('increase-qty') || button.classList.contains('decrease-qty')) { const productId = button.dataset.id; const item = userState.cart.find(i => i.product === productId); if (!item) return; const newQuantity = button.classList.contains('increase-qty') ? item.quantity + 1 : item.quantity - 1; try { userState.cart = await fetchAPI(`${API_BASE_URL}/api/users/cart`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId, quantity: newQuantity }) }); renderCartItems(); updateCartCount(); } catch (error) { console.error('Failed to update quantity'); } }
    });

    // --- 7. INITIAL PAGE LOAD ---
    async function init() {
        try { allProducts = await fetchAPI(`${API_BASE_URL}/api/products`); }
        catch (error) { if (productGrid) productGrid.innerHTML = '<p>Could not load products. Please ensure the backend server is running and accessible.</p>'; }
        await checkLoginStatus();
    }
    
    init();
});