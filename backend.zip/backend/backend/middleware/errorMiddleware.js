// backend/middleware/errorMiddleware.js

// This middleware handles requests for routes that do not exist (404).
const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error); // This passes the error to our master error handler below.
};

// This is our master error handler. All errors thrown in our app will end up here.
const errorHandler = (err, req, res, next) => {
  // Sometimes an error might come in with a 200 OK status code. If so, default to a 500 Server Error.
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  // Mongoose throws a specific error for bad ObjectIDs, we can check for it.
  if (err.name === 'CastError' && err.kind === 'ObjectId') {
    statusCode = 404;
    message = 'Resource not found';
  }

  res.status(statusCode).json({
    message: message,
    // We only want the stack trace in development mode for debugging.
    // In production, this is a security risk and should be hidden.
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};

// CRITICAL STEP: Use a named export to match how we are importing in server.js
export { notFound, errorHandler };