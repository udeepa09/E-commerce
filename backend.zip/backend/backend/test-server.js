import express from 'express';

const app = express();
const port = 9999; // Using a completely new port to avoid any conflicts

// Middleware to understand form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// The ONLY route in this entire server
app.post('/login', (req, res) => {
  console.log('--- TEST SERVER: /login route was successfully hit! ---');
  console.log('--- TEST SERVER: Received data:', req.body);
  
  // Send back a success message
  res.status(200).json({ message: 'SUCCESS! The POST route is working.' });
});

app.listen(port, () => {
  console.log(`>>> Your FINAL TEST server is running at http://localhost:${port}`);
  console.log('>>> The server is listening for a POST request at http://localhost:9999/login');
  console.log('>>> Leave this terminal running.');
});