import express from 'express';

const app = express();
const port = 8888; // Using a completely new and different port

app.get('/', (req, res) => {
  res.send('<h1>SUCCESS! The Test Server is Working!</h1>');
});

app.listen(port, () => {
  console.log('----------------------------------------------------');
  console.log(`>>> The TEST server is running.`);
  console.log(`>>> Please open your web browser and go to this exact address:`);
  console.log(`>>> http://localhost:8888`);
  console.log('----------------------------------------------------');
});