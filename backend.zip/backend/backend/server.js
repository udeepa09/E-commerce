import express from 'express';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

import connectDB from './config/db.js';
import { notFound, errorHandler } from './middleware/errorMiddleware.js';
import productRoutes from './routes/productRoutes.js';
import userRoutes from './routes/userRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';


dotenv.config();
const port = process.env.PORT || 8080; // Changed to 8080 to match your frontend
connectDB();
const app = express();

app.use(cors({ origin: 'http://127.0.0.1:8080', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// API Routes
app.use('/api/products', productRoutes);
app.use('/api/users', userRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/dashboard', dashboardRoutes);


// --- THIS IS THE FINAL, GUARANTEED FIX FOR SERVING FILES ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// This correctly goes up two levels from `backend` to `pozz (2)` and then into `frontend`
const frontendPath = path.join(__dirname, '..', '..', 'frontend'); 

// Serve static files from the 'frontend' folder
app.use(express.static(frontendPath));

// The catch-all route now serves the index.html from the correct path
app.get('*', (req, res) =>
  res.sendFile(path.resolve(frontendPath, 'index.html'))
);
// -----------------------------------------------------------------

// Error Middleware
app.use(notFound);
app.use(errorHandler);

app.listen(port, () => console.log(`Server running on port ${port}`));