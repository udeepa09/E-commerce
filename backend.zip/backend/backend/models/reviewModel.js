// In backend/models/reviewModel.js

import mongoose from 'mongoose';

const reviewSchema = mongoose.Schema(
  {
    // This connects the review to a specific product
    product: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'Product',
    },
    // This connects the review to a specific user
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    rating: {
      type: Number,
      required: true,
    },
    comment: {
      type: String,
      required: true, // You can change to false if comments are optional
    },
  },
  {
    timestamps: true,
  }
);

// This ensures a user can only write one review per product
reviewSchema.index({ product: 1, user: 1 }, { unique: true });

const Review = mongoose.model('Review', reviewSchema);

export default Review;