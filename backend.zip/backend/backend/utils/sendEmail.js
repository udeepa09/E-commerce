// /utils/sendEmail.js

import nodemailer from 'nodemailer';

// IMPORTANT: You need to configure your email provider here.
// For development, using Gmail is easy.
// You MUST enable "Less secure app access" in your Google account settings
// or create an "App Password".
// See: https://support.google.com/accounts/answer/185833

const sendEmail = async (options) => {
    // 1. Create a transporter
    const transporter = nodemailer.createTransport({
        host: process.env.EMAIL_HOST, // e.g., 'smtp.gmail.com'
        port: process.env.EMAIL_PORT, // e.g., 587
        secure: false, // true for 465, false for other ports
        auth: {
            user: process.env.EMAIL_USERNAME, // Your email address
            pass: process.env.EMAIL_PASSWORD, // Your email password or app password
        },
    });

    // 2. Define the email options
    const mailOptions = {
        from: 'ShopMate <your-email@gmail.com>', // Sender address
        to: options.email,                       // Recipient's email from the function call
        subject: options.subject,                // Subject line
        html: options.html,                      // HTML body of the email
    };

    // 3. Actually send the email
    await transporter.sendMail(mailOptions);
};

export default sendEmail;