// backend/routes/productRoutes.js

import express from 'express';
const router = express.Router();
import {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  createProductReview,
  getProductReviews,
  getShopProducts,
} from '../controllers/productController.js';
import { protect, admin } from '../middleware/authMiddleware.js';

// --- Main Product Routes ---
router.route('/')
  .get(getProducts) // For the homepage
  .post(protect, admin, createProduct); // For creating a new product

// --- Dedicated Shop Page Route ---
router.route('/shop').get(getShopProducts); // For the paginated/sorted shop page

// --- Product Review Routes ---
router.route('/:id/reviews')
  .post(protect, createProductReview)
  .get(getProductReviews);

// --- Routes for a Single Product by ID ---
router.route('/:id')
  .get(getProductById)
  .put(protect, admin, updateProduct)
  .delete(protect, admin, deleteProduct);

export default router;