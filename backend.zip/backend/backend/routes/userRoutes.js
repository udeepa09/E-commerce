import express from 'express';
const router = express.Router();
import {
  registerUser,
  loginUser,
  logoutUser,
  addToCart,
  getCart,
  getUserWishlist,
  updateUserWishlist,
   getUserProfile,     // <-- ADD THIS IMPORT
  updateUserProfile,
  clearCart,
    // <-- ADD THIS IMPORT
    // <-- ADD THIS IMPORT
} from '../controllers/userController.js';
import { protect } from '../middleware/authMiddleware.js';

// This line correctly looks for a POST request to "/api/users/register"
router.post('/register', registerUser);
router.post('/login', loginUser); // THIS IS THE CRITICAL LINE
router.post('/logout', logoutUser);
router.route('/cart').post(protect, addToCart).get(protect, getCart);
router.route('/wishlist').get(protect, getUserWishlist).post(protect, updateUserWishlist);
router.route('/profile')
    .get(protect, getUserProfile)     // Get user profile data
    .put(protect, updateUserProfile);   // Update user profile data
// In backend/routes/userRoutes.js
 // New route
router.delete('/cart/clear', protect, clearCart);
export default router;