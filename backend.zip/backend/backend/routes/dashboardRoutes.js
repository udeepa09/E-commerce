
import express from 'express';
const router = express.Router();
import { getDashboardStats, getSalesData } from '../controllers/dashboardController.js';
import { protect, admin } from '../middleware/authMiddleware.js'; // Import security middleware

// --- ADDED protect and admin MIDDLEWARE TO SECURE THE ROUTES ---
router.route('/stats').get(protect, admin, getDashboardStats);
router.route('/sales-data').get(protect, admin, getSalesData);
// ---------------------------------------------------------------

export default router;