// backend/controllers/orderController.js

import asyncHandler from 'express-async-handler';
import Order from '../models/orderModel.js';
import sendEmail from '../utils/sendEmail.js';

 // Import the email sending utility

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
// In backend/controllers/orderController.js

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
// In backend/controllers/orderController.js

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
const addOrderItems = asyncHandler(async (req, res) => {
  const { orderItems, shippingAddress, paymentMethod, totalPrice } = req.body;

  if (!orderItems || orderItems.length === 0) {
    res.status(400);
    throw new Error('No order items');
  } else {
    // --- THE FIX IS HERE ---
    // This new mapping correctly handles the data from checkout.js
    const formattedOrderItems = orderItems.map((item) => ({
        name: item.name,
        quantity: item.quantity,
        image: item.image,
        price: item.price,
        product: item.product, // The product field is already the ID from checkout.js
    }));

    const order = new Order({
        orderItems: formattedOrderItems,
        user: req.user._id,
        shippingAddress,
        paymentMethod,
        totalPrice,
    });

    const createdOrder = await order.save();
    res.status(201).json(createdOrder);
  }
});
// @desc    Get logged in user orders
// @route   GET /api/orders/myorders
// @access  Private
const getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });

  // Add the calculated expected delivery date to each order object
  const ordersWithExpectedDelivery = orders.map(order => {
    const orderObject = order.toObject();

    // Only calculate for orders that are not yet delivered or canceled
    if (orderObject.status !== 'Delivered' && orderObject.status !== 'Canceled') {
      const expectedDeliveryDate = new Date(order.createdAt);
      expectedDeliveryDate.setDate(expectedDeliveryDate.getDate() + 5); // 5-day delivery window
      orderObject.expectedDelivery = expectedDeliveryDate.toISOString();
    }

    return orderObject;
  });

  res.status(200).json(ordersWithExpectedDelivery);
});

// @desc    Get order by ID
// @route   GET /api/orders/:id
// @access  Private
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id).populate(
    'user',
    'name email'
  );

  if (order) {
    res.status(200).json(order);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Update order to paid
// @route   PUT /api/orders/:id/pay
// @access  Private
const updateOrderToPaid = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);

  if (order) {
    order.isPaid = true;
    order.paidAt = Date.now();
    // In a real app, you'd also save paymentResult from PayPal/Stripe here
    const updatedOrder = await order.save();
    res.status(200).json(updatedOrder);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Update order status (and send email)
// @route   PUT /api/orders/:id/status
// @access  Private/Admin
const updateOrderStatus = asyncHandler(async (req, res) => {
  // Populate user details to get their email address
  const order = await Order.findById(req.params.id).populate('user', 'name email');

  if (order) {
    const previousStatus = order.status;
    const newStatus = req.body.status;

    order.status = newStatus || previousStatus;

    if (newStatus === 'Delivered') {
      order.isDelivered = true;
      order.deliveredAt = Date.now();
    }

    const updatedOrder = await order.save();

    // --- TRIGGER EMAIL NOTIFICATION LOGIC ---
    if (newStatus && newStatus !== previousStatus) {
      let emailSubject = '';
      let emailHtml = '';

      if (newStatus === 'Shipped') {
        emailSubject = `Your ShopMate Order #${order._id} has Shipped!`;
        emailHtml = `<p>Hi ${order.user.name}, your order is on its way!</p>`;
      } else if (newStatus === 'Delivered') {
        emailSubject = `Your ShopMate Order #${order._id} has been Delivered!`;
        emailHtml = `<p>Hi ${order.user.name}, your order has arrived. We hope you enjoy it!</p>`;
      }
      
      if (emailSubject) {
        try {
          await sendEmail({
            email: order.user.email,
            subject: emailSubject,
            html: emailHtml,
          });
          console.log(`Email sent successfully for order ${order._id}`);
        } catch (error) {
          console.error(`Failed to send email for order ${order._id}:`, error);
          // Don't stop the process, just log the error. The order update is more critical.
        }
      }
    }

    res.status(200).json(updatedOrder);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Get all orders
// @route   GET /api/orders
// @access  Private/Admin
// In backend/controllers/orderController.js

// ... (other controller functions) ...

// @desc    Get all orders (with filtering and search)
// @route   GET /api/orders
// @access  Private/Admin
const getAllOrders = asyncHandler(async (req, res) => {
    // --- Build the query object based on request queries ---
    const query = {};

    // 1. Filter by status
    if (req.query.status) {
        query.status = req.query.status;
    }

    // 2. Search by customer name (requires a more complex query)
    if (req.query.name) {
        // Find users whose name matches the search term
        const users = await User.find({ name: { $regex: req.query.name, $options: 'i' } });
        // Get an array of just their IDs
        const userIds = users.map(user => user._id);
        // Add this to our main query: find orders where the 'user' field is in our list of userIds
        query.user = { $in: userIds };
    }
    
    // Find all orders that match our constructed query
    const orders = await Order.find({ ...query })
                             .populate('user', 'id name') // Populate user details
                             .sort({ createdAt: -1 }); // Sort by newest first

    res.status(200).json(orders);
});


// Make sure User model is imported at the top of the file
// import User from '../models/userModel.js';

// --- EXPORTS ---
export {
  addOrderItems,
  getMyOrders,
  getOrderById,
  updateOrderToPaid,
  updateOrderStatus,
  getAllOrders,
};