import asyncHandler from 'express-async-handler';
import Product from '../models/productModel.js';
import Review from '../models/reviewModel.js'; // <-- IMPORTANT: Import the Review model

// --- UNCHANGED FUNCTIONS ---
const getProducts = asyncHandler(async (req, res) => {
  const products = await Product.find({});
  res.status(200).json(products);
});
const getShopProducts = asyncHandler(async (req, res) => {
    const pageSize = 8;
    const page = Number(req.query.pageNumber) || 1;

    let sortOptions = {};
    const sortBy = req.query.sort || 'createdAt-desc';
    if (sortBy === 'price-asc') sortOptions = { price: 1 };
    else if (sortBy === 'price-desc') sortOptions = { price: -1 };
    else if (sortBy === 'name-asc') sortOptions = { name: 1 };
    else if (sortBy === 'name-desc') sortOptions = { name: -1 };
    else sortOptions = { createdAt: -1 };
    
    // We are not using a keyword here, just fetching all products
    const count = await Product.countDocuments({});
    const products = await Product.find({})
        .sort(sortOptions)
        .limit(pageSize)
        .skip(pageSize * (page - 1));

    res.json({
        products,
        page,
        pages: Math.ceil(count / pageSize)
    });
});
const getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (product) {
    return res.status(200).json(product);
  } else {
    res.status(404);
    throw new Error('Product not found');
  }
});


// In backend/controllers/productController.js

// @desc    Create a product (as a sample)
// @route   POST /api/products
// @access  Private/Admin
// In backend/controllers/productController.js

// @desc    Create a product (as a sample)
// @route   POST /api/products
// @access  Private/Admin
// In backend/controllers/productController.js

const createProduct = asyncHandler(async (req, res) => {
  const product = new Product({
    // --- THIS IS THE FIX ---
    name: 'Sample Name ' + new Date().toISOString(), // Makes the name unique every time
    
    user: req.user._id,
    image: '/images/sample.jpg',
    brand: 'Sample Brand',
    category: 'Sample Category',
    description: 'Sample description',
  });

  const createdProduct = await product.save();
  res.status(201).json(createdProduct);
});

const updateProduct = asyncHandler(async (req, res) => {
  const { name, price, description, image, brand, category, countInStock } = req.body;
  const product = await Product.findById(req.params.id);
  if (product) {
    product.name = name;
    product.price = price;
    product.description = description;
    product.image = image;
    product.brand = brand;
    product.category = category;
    product.countInStock = countInStock;
    const updatedProduct = await product.save();
    res.status(200).json(updatedProduct);
  } else {
    res.status(404);
    throw new Error('Product not found');
  }
});

const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (product) {
    await Product.deleteOne({ _id: product._id });
    res.status(200).json({ message: 'Product deleted successfully' });
  } else {
    res.status(404);
    throw new Error('Product not found');
  }
});

// --- CORRECTED & IMPROVED createProductReview FUNCTION ---
const createProductReview = asyncHandler(async (req, res) => {
  const { rating, comment } = req.body;

  const product = await Product.findById(req.params.id);

  if (product) {
    // Check if the user has already reviewed this product in the 'reviews' collection
    const alreadyReviewed = await Review.findOne({
      product: req.params.id,
      user: req.user._id,
    });

    if (alreadyReviewed) {
      res.status(400);
      throw new Error('Product already reviewed');
    }

    // Create a new review in the 'reviews' collection
    const review = await Review.create({
      product: req.params.id,
      user: req.user._id,
      rating: Number(rating),
      comment,
    });

    if (review) {
      // Get all reviews for this product to calculate the new average
      const reviews = await Review.find({ product: req.params.id });

      // Update the rating and numReviews fields on the product document
      product.numReviews = reviews.length;
      product.rating = reviews.reduce((acc, item) => item.rating + acc, 0) / reviews.length;

      await product.save();

      res.status(201).json({ message: 'Review added' });
    } else {
      res.status(400);
      throw new Error('Invalid review data');
    }
  } else {
    res.status(404);
    throw new Error('Product not found');
  }
});

// --- NEW FUNCTION TO GET REVIEWS ---
// This is needed for your GET /api/products/:id/reviews route
const getProductReviews = asyncHandler(async (req, res) => {
  const reviews = await Review.find({ product: req.params.id }).populate(
    'user',
    'name'
  );

  if (reviews) {
    res.json(reviews);
  } else {
    res.status(404);
    throw new Error('Reviews not found');
  }
});

// --- UPDATED EXPORTS ---
export {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  createProductReview,
  getProductReviews,
  getShopProducts, // <-- Make sure to export the new function
};