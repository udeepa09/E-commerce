import asyncHandler from 'express-async-handler';
import User from '../models/userModel.js';
import Product from '../models/productModel.js';
import generateToken from '../utils/generateToken.js';

// @desc    Register a new user
const registerUser = asyncHandler(async (req, res) => {
    const { name, email, password } = req.body;
    const userExists = await User.findOne({ email });
    if (userExists) {
        res.status(400);
        throw new Error('User already exists');
    }
    const user = await User.create({ name, email, password });
    if (user) {
        const token = generateToken(res, user._id);
        res.status(201).json({
            _id: user._id,
            name: user.name,
            email: user.email,
            isAdmin: user.isAdmin,
            token: token,
        });
    } else {
        res.status(400);
        throw new Error('Invalid user data');
    }
});

// @desc    Auth user & get token
const loginUser = asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(password))) {
        const token = generateToken(res, user._id);
        res.status(200).json({
            _id: user._id,
            name: user.name,
            email: user.email,
            isAdmin: user.isAdmin,
            token: token,
        });
    } else {
        res.status(401);
        throw new Error('Invalid email or password');
    }
});

// @desc    Logout user and clear cookie
const logoutUser = asyncHandler(async (req, res) => {
  res.cookie('jwt', '', { httpOnly: true, expires: new Date(0) });
  res.status(200).json({ message: 'Logged out successfully' });
});

// @desc    Add/Update item in cart
const addToCart = asyncHandler(async (req, res) => {
    const { productId, quantity } = req.body;
    const product = await Product.findById(productId);
    if (!product) { res.status(404); throw new Error('Product not found'); }
    const user = await User.findById(req.user._id);
    const itemIndex = user.cart.findIndex(item => item.product.toString() === productId);
    if (quantity <= 0) {
        if (itemIndex > -1) user.cart.splice(itemIndex, 1);
    } else {
        if (itemIndex > -1) user.cart[itemIndex].quantity = quantity;
        else user.cart.push({ product: productId, name: product.name, image: product.image, price: product.price, quantity });
    }
    await user.save();
    res.status(200).json(user.cart);
});

// @desc    Get user cart
// In backend/controllers/userController.js

// @desc    Get user's cart
// @route   GET /api/users/cart
// @access  Private
const getCart = asyncHandler(async (req, res) => {
    const user = await User.findById(req.user._id)
        .populate({
            path: 'cart',
            populate: {
                path: 'product',
                model: 'Product',
                // --- THE FIX IS HERE: Ensure 'price' is included in the select string ---
                select: 'name image price countInStock' 
            }
        });

    if (user) {
        res.status(200).json(user.cart);
    } else {
        res.status(404);
        throw new Error('User not found');
    }
});

// @desc    Get user wishlist
const getUserWishlist = asyncHandler(async (req, res) => {
    const user = await User.findById(req.user._id);
    if (user) res.status(200).json({ products: user.wishlist });
    else { res.status(404); throw new Error('User not found'); }
});

// @desc    Update user wishlist (add/remove)
const updateUserWishlist = asyncHandler(async (req, res) => {
    const { productId } = req.body;
    const user = await User.findById(req.user._id);
    if (user) {
        const index = user.wishlist.indexOf(productId);
        if (index > -1) user.wishlist.splice(index, 1);
        else user.wishlist.push(productId);
        await user.save();
        res.status(200).json({ products: user.wishlist });
    } else {
        res.status(404); throw new Error('User not found'); }

});
const getUserProfile = asyncHandler(async (req, res) => {
  // req.user is available because of our 'protect' middleware
  const user = await User.findById(req.user._id);

  if (user) {
    res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
const updateUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    // Update name and email if they are provided in the request body
    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;

    // IMPORTANT: Only update the password if a new one is provided
    if (req.body.password) {
      user.password = req.body.password; // The hashing logic is in your userModel.js
    }

    const updatedUser = await user.save();
    
    // Respond with the updated user info (including a new token if you want, but not necessary here)
    res.status(200).json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      isAdmin: updatedUser.isAdmin,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});
const clearCart = asyncHandler(async (req, res) => {
    const user = await User.findById(req.user._id);
    if (user) {
        user.cart = [];
        await user.save();
        res.status(200).json({ message: 'Cart cleared' });
    } else {
        res.status(404); throw new Error('User not found');
    }
});


// getAllOrders has been REMOVED from this file.
export {
  registerUser,
  loginUser,
  logoutUser,
  addToCart,
  getCart,
  getUserWishlist,
  updateUserWishlist,
   getUserProfile,
  updateUserProfile,
  clearCart ,
};