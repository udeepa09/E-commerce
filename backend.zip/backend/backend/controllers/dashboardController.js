import asyncHandler from 'express-async-handler';
import Product from '../models/productModel.js';
import User from '../models/userModel.js';
import Order from '../models/orderModel.js';

const getDashboardStats = asyncHandler(async (req, res) => {
    const totalProducts = await Product.countDocuments();
    const totalUsers = await User.countDocuments({ isAdmin: false });
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    const ordersToday = await Order.countDocuments({ createdAt: { $gte: today, $lt: tomorrow } });
    const salesData = await Order.aggregate([{ $group: { _id: null, totalSales: { $sum: '$totalPrice' } } }]);
    const totalSales = salesData.length > 0 ? salesData[0].totalSales : 0;
    res.json({ totalProducts, totalUsers, ordersToday, totalSales });
});

const getSalesData = asyncHandler(async (req, res) => {
    const salesByDay = await Order.aggregate([
        { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, totalSales: { $sum: "$totalPrice" } } },
        { $sort: { _id: 1 } }
    ]);
    res.json(salesByDay);
});

export { getDashboardStats, getSalesData };