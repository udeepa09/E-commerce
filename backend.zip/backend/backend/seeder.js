// backend/seeder.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import colors from 'colors';
import users from './data/users.js';
import products from './data/products.js';
import User from './models/userModel.js';
import Product from './models/productModel.js';
import Order from './models/orderModel.js';
import connectDB from './config/db.js';

dotenv.config();
await connectDB(); // Use top-level await now that we use ES Modules

const importData = async () => {
  try {
    // Clear out any old data
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    // Insert the sample users
    const createdUsers = await User.insertMany(users);
    const adminUser = createdUsers[0]._id; // Assume the first user is the admin

    // Add the admin user reference to each sample product
    const sampleProducts = products.map((product) => {
      return { ...product, user: adminUser };
    });

    // Insert the sample products
    await Product.insertMany(sampleProducts);

    console.log('[SEEDER] Data Imported!'.green.inverse);
    process.exit();
  } catch (error) {
    console.error(`[SEEDER] Error: ${error}`.red.inverse);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    console.log('[SEEDER] Data Destroyed!'.yellow.inverse);
    process.exit();
  } catch (error) {
    console.error(`[SEEDER] Error: ${error}`.red.inverse);
    process.exit(1);
  }
};

// Check for command-line arguments to decide which function to run
if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}